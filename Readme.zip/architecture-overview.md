# Architecture Overview: AutoSys → Ab Initio → Airflow DAG Migration Tool

**Date:** 2026-04-10

---

## System Overview

A REST API microservice that accepts AutoSys JIL files and converts them — along with their referenced Ab Initio orchestration plans — into production-grade Google Cloud Composer (Airflow) DAGs. The conversion is performed by a sequential pipeline of 6 specialized AI agents, each powered by Claude Sonnet 4.5 via the Anthropic API.

---

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                        CLIENTS                                       │
│              (CI/CD pipelines, developers, migration tools)          │
└──────────────────────────┬──────────────────────────────────────────┘
                           │ HTTP
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      FastAPI REST API                                │
│                                                                      │
│   POST /convert                    GET /status/{job_id}             │
│   ├── API key auth                 ├── Returns: status, DAGs,       │
│   ├── Fetch JIL (GitHub API)       │   migration report             │
│   └── Enqueue background job       └── Polls in-memory job store   │
└──────────────────────────┬──────────────────────────────────────────┘
                           │ BackgroundTask
                           ▼
┌─────────────────────────────────────────────────────────────────────┐
│                   Pipeline Orchestrator                              │
│                                                                      │
│   Runs 6 agents sequentially.                                       │
│   Passes PipelineState through each agent.                          │
│   Handles hard failures (halt) and soft failures (continue).        │
└────┬────────┬────────┬────────┬────────┬────────┬───────────────────┘
     │        │        │        │        │        │
     ▼        ▼        ▼        ▼        ▼        ▼
  Agent 1  Agent 2  Agent 3  Agent 4  Agent 5  Agent 6
 JIL      EME      Orch.    Conv.    Valid.   Report
 Parser  Fetcher  Analyzer
```

---

## Data Flow

```
GitHub Repo (JIL files)
        │
        │  raw JIL text
        ▼
┌───────────────┐
│  Agent 1:     │  parse_jil_blocks()
│  JIL Parser   │  extract_job_attributes()    ──→  List[AutoSysJob]
│               │  extract_abinitio_plan()
└───────────────┘
        │
        │  List of .pset plan names
        ▼
┌───────────────┐
│  Agent 2:     │  air repository export (CLI)
│  EME Fetcher  │  parse_eme_xml()              ──→  Dict[str, AbInitioPlan]
│               │  (shell=False, no injection)
└───────────────┘
        │
        │  AutoSysJobs + AbInitioPlans
        ▼
┌───────────────────────┐
│  Agent 3:             │  build_autosys_dag_graph()
│  Orchestration        │  build_abinitio_task_graph()  ──→  OrchestrationModel
│  Analyzer             │  resolve_sub_plan_references()
│                       │  convert_schedule_to_cron()
└───────────────────────┘
        │
        │  OrchestrationModel (DagGroups + TaskNodes + Dependencies)
        ▼
┌───────────────────────┐
│  Agent 4:             │  lookup_known_mapping()   (mappings.yaml)
│  Conversion           │  infer_mapping_with_llm() (Claude API call)  ──→  Dict[dag_id, Python code]
│                       │  generate_dag_code()      (Jinja2 template)
└───────────────────────┘
        │
        │  Generated Airflow DAG Python code
        ▼
┌───────────────┐
│  Agent 5:     │  validate_python_syntax()  (ast.parse)
│  Validation   │  validate_dagbag()         (Airflow DagBag + SQLite)  ──→  Dict[dag_id, ValidationResult]
└───────────────┘
        │
        │  All state
        ▼
┌───────────────┐
│  Agent 6:     │  Pure aggregation (no LLM)
│  Report       │  Builds MigrationReport     ──→  MigrationReport
└───────────────┘
        │
        ▼
   PipelineState
   (DAGs + Report + Status)
        │
        ▼
   Job Store (in-memory)
        │
        ▼
   GET /status/{job_id}  →  Client
```

---

## Component Breakdown

### REST API Layer (`api/`)

| Component | Responsibility |
|-----------|---------------|
| `api/main.py` | FastAPI app; `/convert` and `/status/{job_id}` endpoints; API key auth; job store management |
| `api/models.py` | `ConvertRequest`, `ConvertResponse`, `StatusResponse` Pydantic models |

### Pipeline Layer (`pipeline/`)

| Component | Responsibility |
|-----------|---------------|
| `pipeline/state.py` | All shared Pydantic models: `PipelineState`, `AutoSysJob`, `AbInitioPlan`, `OrchestrationModel`, `MigrationReport`, etc. |
| `pipeline/orchestrator.py` | Runs agents 1–6 sequentially; passes `PipelineState`; handles failure modes |
| `pipeline/agents/base.py` | Shared agent loop: Claude API calls, stop_reason handling, tool execution, rate limit backoff, max iteration guard |

### Agent Layer (`pipeline/agents/`)

| Agent | File | LLM? | Primary Output |
|-------|------|------|---------------|
| 1 — JIL Parser | `jil_parser.py` | Yes | `List[AutoSysJob]` |
| 2 — EME Fetcher | `eme_fetcher.py` | No (deterministic) | `Dict[str, AbInitioPlan]` |
| 3 — Orchestration Analyzer | `orchestration_analyzer.py` | Yes | `OrchestrationModel` |
| 4 — Conversion | `conversion.py` | Yes (+ nested inference calls) | `Dict[str, str]` (DAG code) |
| 5 — Validation | `validation.py` | No (deterministic) | `Dict[str, ValidationResult]` |
| 6 — Report | `report.py` | No (aggregation) | `MigrationReport` |

### Tool Layer (`tools/`)

| File | Provides |
|------|---------|
| `tools/jil_tools.py` | `parse_jil_blocks`, `extract_job_attributes`, `extract_abinitio_plan`, `parse_conditions`, `parse_schedule` |
| `tools/eme_tools.py` | `run_eme_export` (secure CLI wrapper, `shell=False`), `parse_eme_xml` |
| `tools/mapping_tools.py` | `lookup_known_mapping` (reads `config/mappings.yaml`) |
| `tools/airflow_tools.py` | `validate_python_syntax` (`ast.parse`), `validate_dagbag` (Airflow DagBag + SQLite) |

### Configuration & Templates

| File | Purpose |
|------|---------|
| `config/mappings.yaml` | Ab Initio component type → GCP operator registry. Edit to add mappings without code changes. |
| `templates/dag_template.py.j2` | Jinja2 template for generated Airflow DAG files. Enforces all Airflow industry standards. |

---

## Key Data Models

### PipelineState (flows through all agents)
```
PipelineState
├── job_id: str
├── raw_jil: str
├── parsed_jobs: List[AutoSysJob]      ← output of Agent 1
├── eme_plans: Dict[str, AbInitioPlan] ← output of Agent 2
├── skipped_plans: List[str]           ← EME soft failures
├── orchestration_model: OrchestrationModel ← output of Agent 3
├── generated_dags: Dict[str, str]     ← output of Agent 4 (dag_id → Python)
├── validation_results: Dict[str, ValidationResult] ← output of Agent 5
├── agent_errors: List[AgentError]     ← accumulated across all agents
├── report: MigrationReport            ← output of Agent 6
├── status: running|success|partial|failed
└── confidence_threshold: float (default 0.7)
```

### OrchestrationModel (unified two-layer model)
```
OrchestrationModel
├── dag_groups: List[DagGroup]
│   └── DagGroup
│       ├── dag_id: str (snake_case, unique)
│       ├── schedule: Optional[str] (cron expression)
│       ├── schedule_requires_review: bool
│       ├── tasks: List[TaskNode]
│       │   └── TaskNode
│       │       ├── source: autosys|abinitio|synthetic
│       │       ├── component_type: str
│       │       ├── sub_dag_ref: Optional[str] (for TriggerDagRunOperator)
│       │       └── parameters: Dict[str, Any]
│       └── dependencies: List[Dependency]
│           └── Dependency (upstream_task_id → downstream_task_id)
└── circular_dependency_warnings: List[str]
```

---

## External System Interactions

```
┌─────────────────────────────────────────────────────────────┐
│                   Migration API Service                      │
│                                                             │
│  ┌──────────┐    ┌────────────────────────────────────────┐ │
│  │ Agent 1  │───▶│  GitHub API                            │ │
│  │ JIL      │    │  GET /repos/{owner}/{repo}/contents    │ │
│  │ Parser   │    │  Auth: GITHUB_TOKEN (env var)          │ │
│  └──────────┘    └────────────────────────────────────────┘ │
│                                                             │
│  ┌──────────┐    ┌────────────────────────────────────────┐ │
│  │ Agent 2  │───▶│  Ab Initio EME Server                  │ │
│  │ EME      │    │  CLI: air repository export <plan>     │ │
│  │ Fetcher  │    │  Host: EME_HOST env var                │ │
│  └──────────┘    └────────────────────────────────────────┘ │
│                                                             │
│  ┌──────────┐    ┌────────────────────────────────────────┐ │
│  │ Agents   │───▶│  Anthropic API (Claude Sonnet 4.5)     │ │
│  │ 1, 3, 4  │    │  Auth: ANTHROPIC_API_KEY (env var)     │ │
│  └──────────┘    └────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

---

## Agent Loop Architecture

Each LLM-powered agent uses the same core loop pattern:

```
Agent Entry
    │
    ▼
Build initial message (inject state data)
    │
    ▼
┌──────────────────────────────────────┐
│           AGENT LOOP                  │
│  (max 20 iterations)                  │
│                                       │
│  Call Claude API                      │
│       │                               │
│       ├── stop_reason: end_turn ──────┼──→ Parse output → Return
│       │                               │
│       ├── stop_reason: max_tokens ────┼──→ Append "continue" → Loop
│       │                               │
│       ├── stop_reason: tool_use ──────┼──→ Execute tool → Append result → Loop
│       │                               │
│       ├── RateLimitError ─────────────┼──→ Sleep 60s → Retry
│       │                               │
│       └── APITimeoutError ────────────┼──→ Raise AgentTimeoutError
│                                       │
│  (> 20 iterations) ───────────────────┼──→ Raise AgentLoopError
└──────────────────────────────────────┘
```

---

## Deployment Architecture (MVP)

```
┌─────────────────────────────────────────────────────────────┐
│                   Single Container                           │
│                                                             │
│   uvicorn api.main:app --host 0.0.0.0 --port 8080           │
│                                                             │
│   Environment Variables:                                    │
│   ├── ANTHROPIC_API_KEY  (mounted K8s secret)               │
│   ├── GITHUB_TOKEN       (mounted K8s secret)               │
│   ├── API_KEY            (mounted K8s secret)               │
│   └── EME_HOST           (ConfigMap)                        │
└─────────────────────────────────────────────────────────────┘
```

**Production upgrade path:**
- Replace in-memory job store with Redis (job_id → PipelineState JSON)
- Replace `BackgroundTasks` with Cloud Tasks or Celery workers for horizontal scaling
- Add Cloud Logging for structured log output per job

---

## File Structure

```
autosys-to-airflow/
├── api/
│   ├── __init__.py
│   ├── main.py                          # FastAPI app
│   └── models.py                        # Request/response models
├── pipeline/
│   ├── __init__.py
│   ├── orchestrator.py                  # Sequential pipeline runner
│   ├── state.py                         # All shared Pydantic models
│   └── agents/
│       ├── __init__.py
│       ├── base.py                      # Shared agent loop
│       ├── jil_parser.py               # Agent 1
│       ├── eme_fetcher.py              # Agent 2
│       ├── orchestration_analyzer.py   # Agent 3
│       ├── conversion.py               # Agent 4
│       ├── validation.py               # Agent 5
│       └── report.py                   # Agent 6
├── tools/
│   ├── __init__.py
│   ├── jil_tools.py
│   ├── eme_tools.py
│   ├── mapping_tools.py
│   └── airflow_tools.py
├── templates/
│   └── dag_template.py.j2
├── config/
│   └── mappings.yaml
├── tests/
│   ├── fixtures/
│   │   ├── sample_jobs.jil
│   │   ├── sample_plan.xml
│   │   └── expected_dag.py
│   ├── test_jil_parser.py
│   ├── test_eme_fetcher.py
│   ├── test_conversion.py
│   └── test_validation.py
└── requirements.txt
```
