# Implementation Plan: AutoSys → Ab Initio → Airflow DAG Migration Tool

**Date:** 2026-04-10
**Stack:** Python 3.11+, FastAPI, Pydantic v2, Anthropic Claude Sonnet 4.5, Apache Airflow ≥ 2.4, Jinja2

---

## Build Order

Always build in this order — later steps depend on earlier ones:

```
Phase 1: Scaffold + Shared Models
  Step 1  — Project structure + requirements.txt
  Step 2  — pipeline/state.py  (all Pydantic models — built first, everything imports from here)
  Step 3  — config/mappings.yaml

Phase 2: Tool Implementations
  Step 4  — tools/jil_tools.py
  Step 5  — tools/eme_tools.py  (security-critical: shell=False)
  Step 6  — tools/mapping_tools.py
  Step 7  — tools/airflow_tools.py
  Step 8  — templates/dag_template.py.j2

Phase 3: Agent Implementations
  Step 9  — pipeline/agents/base.py  (shared agent loop)
  Step 10 — pipeline/agents/jil_parser.py  (Agent 1)
  Step 11 — pipeline/agents/eme_fetcher.py  (Agent 2)
  Step 12 — pipeline/agents/orchestration_analyzer.py  (Agent 3)
  Step 13 — pipeline/agents/conversion.py  (Agent 4)
  Step 14 — pipeline/agents/validation.py  (Agent 5)
  Step 15 — pipeline/agents/report.py  (Agent 6)
  Step 16 — pipeline/orchestrator.py

Phase 4: REST API
  Step 17 — api/models.py
  Step 18 — api/main.py

Phase 5: Tests
  Step 19 — tests/fixtures/ (sample JIL, EME XML, expected DAG)
  Step 20 — tests/test_*.py

Phase 6: Verification
  Step 21 — End-to-end verification checklist
```

---

## Phase 1: Project Scaffold and Shared Models

### Step 1 — Project Structure

Create this directory tree with empty `__init__.py` in each package directory:

```
autosys-to-airflow/
├── api/__init__.py
├── pipeline/__init__.py
├── pipeline/agents/__init__.py
├── tools/__init__.py
├── templates/
├── config/
└── tests/fixtures/
```

Create `requirements.txt`:
```
fastapi>=0.111.0
uvicorn[standard]>=0.29.0
pydantic>=2.7.0
anthropic>=0.26.0
apache-airflow>=2.9.0
jinja2>=3.1.4
pyyaml>=6.0.1
httpx>=0.27.0
pytest>=8.2.0
pytest-asyncio>=0.23.0
```

---

### Step 2 — `pipeline/state.py`

This file defines **all shared Pydantic models**. Build in this dependency order:

**AutoSys models:**
```python
class ConditionType(str, Enum):
    SUCCESS = "s"        # s(JobA) — downstream runs if JobA succeeded
    FAILURE = "f"        # f(JobA) — downstream runs if JobA failed
    NOTRUNNING = "n"     # n(JobA) — downstream runs if JobA not running
    DONE = "d"           # d(JobA) — downstream runs if JobA in any terminal state

class Condition(BaseModel):
    condition_type: ConditionType
    job_name: str
    operator: Optional[Literal["AND", "OR"]] = None

class JobSchedule(BaseModel):
    run_calendar: Optional[str] = None
    run_window: Optional[str] = None
    start_times: List[str] = Field(default_factory=list)
    timezone: Optional[str] = None
    cron_expression: Optional[str] = None      # populated by Agent 3
    requires_manual_review: bool = False       # True if calendar is too complex to auto-convert

class AutoSysJob(BaseModel):
    job_name: str
    job_type: Literal["BOX", "CMD"]
    box_name: Optional[str] = None
    conditions: List[Condition] = Field(default_factory=list)
    abinitio_plan: Optional[str] = None        # e.g. "MyPlan.pset"
    schedule: Optional[JobSchedule] = None
    machine: Optional[str] = None
    owner: Optional[str] = None
```

**Ab Initio models:**
```python
class ComponentPort(BaseModel):
    port_name: str
    connected_to: Optional[str] = None   # component_id of downstream component

class Component(BaseModel):
    component_id: str
    component_type: str                   # maps to abinitio_type in mappings.yaml
    label: Optional[str] = None
    parameters: Dict[str, str] = Field(default_factory=dict)
    input_ports: List[ComponentPort] = Field(default_factory=list)
    output_ports: List[ComponentPort] = Field(default_factory=list)

class Phase(BaseModel):
    phase_id: str
    phase_name: str
    components: List[str] = Field(default_factory=list)   # component_ids
    depends_on: List[str] = Field(default_factory=list)   # phase_ids

class AbInitioPlan(BaseModel):
    plan_name: str
    phases: List[Phase] = Field(default_factory=list)
    components: List[Component] = Field(default_factory=list)
    sub_plans: List[str] = Field(default_factory=list)    # nested plan names
    parameters: Dict[str, str] = Field(default_factory=dict)
    eme_path: str = ""
```

**Orchestration models:**
```python
class TaskSourceType(str, Enum):
    AUTOSYS = "autosys"
    ABINITIO = "abinitio"
    SYNTHETIC = "synthetic"    # glue tasks: TriggerDagRunOperator, sensors

class TaskNode(BaseModel):
    task_id: str
    source: TaskSourceType
    component_type: str
    parameters: Dict[str, Any] = Field(default_factory=dict)
    sub_dag_ref: Optional[str] = None    # dag_id to trigger (sub-plan calls)
    original_name: str

class Dependency(BaseModel):
    upstream_task_id: str
    downstream_task_id: str

class DagGroup(BaseModel):
    dag_id: str                          # snake_case, unique
    description: str = ""
    schedule: Optional[str] = None       # cron expression
    schedule_requires_review: bool = False
    tasks: List[TaskNode] = Field(default_factory=list)
    dependencies: List[Dependency] = Field(default_factory=list)
    tags: List[str] = Field(default_factory=list)
    source_box_job: str = ""

class OrchestrationModel(BaseModel):
    dag_groups: List[DagGroup] = Field(default_factory=list)
    circular_dependency_warnings: List[str] = Field(default_factory=list)
```

**Report models:**
```python
class AgentError(BaseModel):
    agent_name: str
    error_type: str
    message: str
    recoverable: bool = True

class TaskConversionDetail(BaseModel):
    task_id: str
    dag_id: str
    operator: str
    confidence: float                    # 0.0–1.0
    source: Literal["known_mapping", "llm_inference", "fallback"]
    rationale: Optional[str] = None      # populated for llm_inference
    review_required: bool = False

class DagConversionSummary(BaseModel):
    dag_id: str
    source_box_job: str
    total_tasks: int = 0
    tasks_converted: int = 0
    tasks_flagged: int = 0
    validation_passed: bool = False
    schedule_reviewed: bool = False

class ValidationResult(BaseModel):
    dag_id: str
    syntax_valid: bool = False
    dagbag_valid: bool = False
    dagbag_errors: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)

class MigrationReport(BaseModel):
    total_jobs: int = 0
    total_plans: int = 0
    dags_generated: int = 0
    tasks_converted: int = 0
    tasks_flagged_for_review: int = 0
    skipped_plans: List[str] = Field(default_factory=list)
    agent_errors: List[AgentError] = Field(default_factory=list)
    dag_summaries: List[DagConversionSummary] = Field(default_factory=list)
    task_details: List[TaskConversionDetail] = Field(default_factory=list)
    overall_health_score: float = 0.0
    # Formula: mean(task.confidence for all tasks) * (0.5 if any dagbag_valid=False else 1.0)
    # Range: 0.0–1.0
```

**Pipeline state:**
```python
class PipelineState(BaseModel):
    job_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    raw_jil: str = ""
    parsed_jobs: List[AutoSysJob] = Field(default_factory=list)
    eme_plans: Dict[str, AbInitioPlan] = Field(default_factory=dict)
    skipped_plans: List[str] = Field(default_factory=list)
    orchestration_model: Optional[OrchestrationModel] = None
    generated_dags: Dict[str, str] = Field(default_factory=dict)   # dag_id → Python source
    validation_results: Dict[str, ValidationResult] = Field(default_factory=dict)
    agent_errors: List[AgentError] = Field(default_factory=list)
    report: Optional[MigrationReport] = None
    status: Literal["running", "success", "partial", "failed"] = "running"
    confidence_threshold: float = 0.7
```

---

### Step 3 — `config/mappings.yaml`

```yaml
mappings:
  - abinitio_type: "read_file"
    gcp_operator: "GCSToLocalFilesystemOperator"
    import_path: "airflow.providers.google.cloud.transfers.gcs_to_local"
    required_params: ["bucket", "object_name", "filename"]

  - abinitio_type: "write_file"
    gcp_operator: "LocalFilesystemToGCSOperator"
    import_path: "airflow.providers.google.cloud.transfers.local_to_gcs"
    required_params: ["src", "dst", "bucket"]

  - abinitio_type: "run_sql"
    gcp_operator: "BigQueryExecuteQueryOperator"
    import_path: "airflow.providers.google.cloud.operators.bigquery"
    required_params: ["sql", "use_legacy_sql"]

  - abinitio_type: "run_program"
    gcp_operator: "BashOperator"
    import_path: "airflow.operators.bash"
    required_params: ["bash_command"]

  - abinitio_type: "sort"
    gcp_operator: "DataprocSubmitJobOperator"
    import_path: "airflow.providers.google.cloud.operators.dataproc"
    required_params: ["project_id", "region", "job"]

  - abinitio_type: "join"
    gcp_operator: "DataprocSubmitJobOperator"
    import_path: "airflow.providers.google.cloud.operators.dataproc"
    required_params: ["project_id", "region", "job"]

  - abinitio_type: "reformat"
    gcp_operator: "DataflowTemplateOperator"
    import_path: "airflow.providers.google.cloud.operators.dataflow"
    required_params: ["template", "project_id", "location"]

  - abinitio_type: "rollup"
    gcp_operator: "DataprocSubmitJobOperator"
    import_path: "airflow.providers.google.cloud.operators.dataproc"
    required_params: ["project_id", "region", "job"]

  - abinitio_type: "gather"
    gcp_operator: "DataprocSubmitJobOperator"
    import_path: "airflow.providers.google.cloud.operators.dataproc"
    required_params: ["project_id", "region", "job"]

  - abinitio_type: "dedup_sorted"
    gcp_operator: "DataprocSubmitJobOperator"
    import_path: "airflow.providers.google.cloud.operators.dataproc"
    required_params: ["project_id", "region", "job"]

  - abinitio_type: "trigger_dag"
    gcp_operator: "TriggerDagRunOperator"
    import_path: "airflow.operators.trigger_dagrun"
    required_params: ["trigger_dag_id"]
    fixed_params:
      wait_for_completion: true
      poke_interval: 60
```

---

## Phase 2: Tool Implementations

### Step 4 — `tools/jil_tools.py`

Key functions to implement:

- **`parse_jil_blocks(jil_text: str) -> List[str]`** — split on `insert_job:` keyword; each block ends at the next `insert_job:` or EOF
- **`extract_job_attributes(block: str) -> Dict[str, str]`** — parse `key: value` lines; handle multi-line values
- **`extract_abinitio_plan(command: str) -> Optional[str]`** — regex: `r'air\s+sandbox\s+run\s+([a-zA-Z0-9_\-\.]+\.pset)'`
- **`parse_conditions(condition_str: str) -> List[Condition]`** — parse `s(JobA) & f(JobB)` into `List[Condition]`; handle `&` (AND) and `|` (OR) operators
- **`parse_schedule(attrs: Dict) -> Optional[JobSchedule]`** — build from `run_calendar`, `run_window`, `start_times` attributes; set `requires_manual_review=True` if `run_calendar` is present (complex to auto-convert)
- **`jil_to_autosys_jobs(jil_text: str) -> List[AutoSysJob]`** — top-level orchestrator: calls above functions

---

### Step 5 — `tools/eme_tools.py` (Security-Critical)

```python
import re, subprocess, xml.etree.ElementTree as ET
from pipeline.state import AbInitioPlan, Component, ComponentPort, Phase

# CRITICAL: no path separators — prevents path traversal
SAFE_PLAN_NAME_RE = re.compile(r'^[a-zA-Z0-9_\-\.]+\.pset$')

def run_eme_export(plan_name: str, eme_host: str, timeout: int = 30) -> str:
    if not SAFE_PLAN_NAME_RE.match(plan_name):
        raise ValueError(f"Unsafe plan name rejected: {plan_name!r}")
    result = subprocess.run(
        ["air", "repository", "export", plan_name, "-server", eme_host],
        shell=False,          # NEVER change to shell=True
        capture_output=True,
        text=True,
        timeout=timeout
    )
    if result.returncode != 0:
        raise RuntimeError(f"EME export failed: {result.stderr}")
    return result.stdout

def parse_eme_xml(xml_content: str, plan_name: str) -> AbInitioPlan:
    root = ET.fromstring(xml_content)
    # Parse XML structure → AbInitioPlan
    # Map XML element names to component_type strings matching mappings.yaml
    # Extract phases, components (with ports), sub_plans, parameters
    ...
```

Note: The exact XML structure of EME exports must be validated against a real export. Implement `parse_eme_xml` based on the actual XML schema produced by your EME version.

---

### Step 6 — `tools/mapping_tools.py`

```python
import yaml
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional

CONFIG_PATH = Path(__file__).parent.parent / "config" / "mappings.yaml"

@dataclass
class MappingEntry:
    abinitio_type: str
    gcp_operator: str
    import_path: str
    required_params: list = field(default_factory=list)
    fixed_params: dict = field(default_factory=dict)

_MAPPINGS: dict[str, MappingEntry] = {}

def load_mappings() -> None:
    global _MAPPINGS
    with open(CONFIG_PATH) as f:
        data = yaml.safe_load(f)
    _MAPPINGS = {m["abinitio_type"]: MappingEntry(**m) for m in data["mappings"]}

def lookup_known_mapping(component_type: str) -> Optional[MappingEntry]:
    if not _MAPPINGS:
        load_mappings()
    return _MAPPINGS.get(component_type.lower())
```

---

### Step 7 — `tools/airflow_tools.py`

```python
import ast, tempfile, os
from typing import Tuple, List

def validate_python_syntax(dag_code: str) -> Tuple[bool, List[str]]:
    try:
        ast.parse(dag_code)
        return True, []
    except SyntaxError as e:
        return False, [f"SyntaxError at line {e.lineno}: {e.msg}"]

def validate_dagbag(dag_code: str, dag_id: str) -> Tuple[bool, List[str]]:
    with tempfile.TemporaryDirectory() as tmpdir:
        dag_file = os.path.join(tmpdir, f"{dag_id}.py")
        with open(dag_file, "w") as f:
            f.write(dag_code)
        os.environ["AIRFLOW__DATABASE__SQL_ALCHEMY_CONN"] = f"sqlite:///{tmpdir}/airflow.db"
        os.environ["AIRFLOW__CORE__DAGS_FOLDER"] = tmpdir
        try:
            from airflow.models import DagBag
            dagbag = DagBag(dag_folder=tmpdir, include_examples=False)
            if dagbag.import_errors:
                return False, [f"{k}: {v}" for k, v in dagbag.import_errors.items()]
            return True, []
        except Exception as e:
            return False, [str(e)]
```

---

### Step 8 — `templates/dag_template.py.j2`

The template must enforce all Airflow industry standards:

```jinja2
# Auto-generated by AutoSys→Airflow Migration Tool
# Source box job: {{ dag_group.source_box_job }}
# Generated: {{ generation_date }}
{% if dag_group.schedule_requires_review %}
# WARNING: Schedule requires manual review — original AutoSys run_calendar was complex
{% endif %}

from datetime import datetime, timedelta
from airflow import DAG
{% for import_path, operator_name in imports %}
from {{ import_path }} import {{ operator_name }}
{% endfor %}

default_args = {
    "owner": "migration",
    "retries": 3,
    "retry_delay": timedelta(minutes=5),
}

with DAG(
    dag_id="{{ dag_group.dag_id }}",
    description="{{ dag_group.description | e }}",
    schedule={{ dag_group.schedule | tojson }},
    start_date=datetime({{ start_year }}, {{ start_month }}, {{ start_day }}),
    default_args=default_args,
    catchup=False,
    tags={{ dag_group.tags | tojson }},
) as dag:
{% for task in tasks %}
    {{ task.task_id }} = {{ task.operator_class }}(
        task_id="{{ task.task_id }}",
        {% for param_key, param_value in task.operator_params.items() %}
        {{ param_key }}={{ param_value | tojson }},
        {% endfor %}
    )
{% endfor %}

{% for dep in dag_group.dependencies %}
    {{ dep.upstream_task_id }} >> {{ dep.downstream_task_id }}
{% endfor %}
```

---

## Phase 3: Agent Implementations

### Step 9 — `pipeline/agents/base.py` (Shared Agent Loop)

The shared loop used by all LLM agents:

```python
import time
from typing import Any, Callable, Dict, List
import anthropic

MAX_AGENT_ITERATIONS = 20
client = anthropic.Anthropic()

def run_agent_loop(
    agent_name: str,
    system_prompt: str,
    tools: List[Dict],
    initial_message: str,
    tool_executor: Callable[[str, Dict], Any],
    model: str = "claude-sonnet-4-5"
) -> str:
    messages = [{"role": "user", "content": initial_message}]
    iterations = 0

    while iterations < MAX_AGENT_ITERATIONS:
        iterations += 1
        try:
            response = client.messages.create(
                model=model,
                system=system_prompt,
                tools=tools,
                messages=messages,
                max_tokens=8096,
                timeout=120.0
            )
        except anthropic.RateLimitError:
            time.sleep(60)
            continue
        except anthropic.APITimeoutError:
            raise RuntimeError(f"{agent_name}: API timeout at iteration {iterations}")

        if response.stop_reason == "end_turn":
            for block in response.content:
                if hasattr(block, "text"):
                    return block.text
            return ""
        elif response.stop_reason == "max_tokens":
            messages.append({"role": "assistant", "content": response.content})
            messages.append({"role": "user", "content": "Please continue."})
        elif response.stop_reason == "tool_use":
            tool_results = []
            for block in response.content:
                if block.type == "tool_use":
                    result = tool_executor(block.name, block.input)
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": str(result)
                    })
            messages.append({"role": "assistant", "content": response.content})
            messages.append({"role": "user", "content": tool_results})
        else:
            raise RuntimeError(f"{agent_name}: Unexpected stop_reason: {response.stop_reason}")

    raise RuntimeError(f"{agent_name}: Exceeded MAX_AGENT_ITERATIONS ({MAX_AGENT_ITERATIONS})")
```

---

### Step 10 — `pipeline/agents/jil_parser.py` (Agent 1)

**System prompt:** Instructs Claude to parse JIL text using the provided tools, extract all `insert_job` blocks, their job types, conditions, commands, schedules, and Ab Initio plan references. Return a JSON array of `AutoSysJob` objects.

**Tools exposed to LLM:**
- `parse_jil_blocks(jil_text)` → list of raw blocks
- `extract_job_attributes(block)` → dict of attributes
- `extract_abinitio_plan(command)` → plan name or null

**Output:** Parse LLM's JSON response → `List[AutoSysJob]` → set `state.parsed_jobs`

**Failure mode:** If parsing fails (invalid JSON, invalid model), add `AgentError(recoverable=False)`, set `state.status = "failed"`.

---

### Step 11 — `pipeline/agents/eme_fetcher.py` (Agent 2)

No LLM loop needed — deterministic tool execution:

```python
def run_eme_fetcher(state: PipelineState, eme_host: str) -> PipelineState:
    plan_names = list({j.abinitio_plan for j in state.parsed_jobs if j.abinitio_plan})

    for plan_name in plan_names:
        for attempt in range(3):
            try:
                xml = run_eme_export(plan_name, eme_host)
                state.eme_plans[plan_name] = parse_eme_xml(xml, plan_name)
                break
            except Exception as e:
                if attempt == 2:   # final attempt failed
                    state.skipped_plans.append(plan_name)
                    state.agent_errors.append(AgentError(
                        agent_name="eme_fetcher",
                        error_type=type(e).__name__,
                        message=str(e),
                        recoverable=True
                    ))
                else:
                    time.sleep(2 ** attempt)   # 1s, 2s backoff
    return state
```

---

### Step 12 — `pipeline/agents/orchestration_analyzer.py` (Agent 3)

**System prompt:** Instructs Claude to:
1. Build the AutoSys DAG graph (resolve condition strings to dependencies, group CMD jobs by their BOX parent)
2. For each DAG group, integrate the Ab Initio plan structure (phases → task ordering, components → TaskNodes)
3. Mark sub-plan calls as SYNTHETIC tasks with `sub_dag_ref` set
4. Convert schedules to cron; set `schedule_requires_review=True` for complex calendars
5. Detect circular sub-plan references
6. Return a JSON `OrchestrationModel`

**Tools exposed to LLM:**
- `build_autosys_dag_graph(jobs_json)` → DAG graph with dependency edges
- `build_abinitio_task_graph(plan_json)` → ordered task list from phase graph
- `resolve_sub_plan_references(plans_json)` → sub-plan call map + cycle detection
- `convert_schedule_to_cron(schedule_json)` → cron string + review flag

**Output:** Parse → `OrchestrationModel` → set `state.orchestration_model`

---

### Step 13 — `pipeline/agents/conversion.py` (Agent 4)

**System prompt:** Instructs Claude to convert each `DagGroup` in the `OrchestrationModel` to Airflow Python code by mapping each `TaskNode.component_type` to a GCP operator, then rendering the Jinja2 template.

**Tools exposed to LLM:**
- `lookup_known_mapping(component_type)` → `MappingEntry` or null
- `infer_mapping_with_llm(component_type, parameters, context)` → `{operator, import_path, confidence, rationale}` (nested Claude call)
- `generate_dag_code(dag_group_json, task_mappings_json)` → Python DAG source string

**Confidence rules:**
- Known mapping: `confidence = 1.0`
- LLM inference: use returned `confidence` value
- Below `state.confidence_threshold`: use `BashOperator` fallback, `confidence = 0.0`, `review_required = True`

**Output:** `state.generated_dags` (dict of dag_id → Python source) + task conversion details for report

**`infer_mapping_with_llm` nested call pattern:**
```python
def infer_mapping_with_llm(component_type: str, parameters: dict, context: str) -> dict:
    response = client.messages.create(
        model="claude-sonnet-4-5",
        max_tokens=512,
        messages=[{"role": "user", "content": f"""
Ab Initio component type: '{component_type}'
Parameters: {json.dumps(parameters)}
Context: {context}

What is the most appropriate Google Cloud Composer (Airflow 2.4+) operator?
Respond with JSON only:
{{"operator": "...", "import_path": "...", "confidence": 0.0-1.0, "rationale": "..."}}
"""}]
    )
    return json.loads(response.content[0].text)
```

---

### Step 14 — `pipeline/agents/validation.py` (Agent 5)

No LLM loop needed — deterministic:

```python
def run_validation(state: PipelineState) -> PipelineState:
    for dag_id, dag_code in state.generated_dags.items():
        syntax_valid, syntax_errors = validate_python_syntax(dag_code)
        if not syntax_valid:
            state.validation_results[dag_id] = ValidationResult(
                dag_id=dag_id, syntax_valid=False, dagbag_valid=False,
                dagbag_errors=syntax_errors
            )
            continue
        dagbag_valid, dagbag_errors = validate_dagbag(dag_code, dag_id)
        state.validation_results[dag_id] = ValidationResult(
            dag_id=dag_id, syntax_valid=True,
            dagbag_valid=dagbag_valid, dagbag_errors=dagbag_errors
        )
    return state
```

---

### Step 15 — `pipeline/agents/report.py` (Agent 6)

No LLM call — pure aggregation:

```python
def run_report(state: PipelineState) -> PipelineState:
    # Collect task_details from state (populated by Agent 4)
    task_details = state._task_details  # stored on state by conversion agent

    all_confidences = [t.confidence for t in task_details]
    all_valid = all(v.dagbag_valid for v in state.validation_results.values())
    avg_conf = sum(all_confidences) / len(all_confidences) if all_confidences else 0.0
    health_score = round(avg_conf * (1.0 if all_valid else 0.5), 3)

    dag_summaries = [
        DagConversionSummary(
            dag_id=dag_id,
            source_box_job=next(
                (g.source_box_job for g in state.orchestration_model.dag_groups if g.dag_id == dag_id), ""
            ),
            total_tasks=len([t for t in task_details if t.dag_id == dag_id]),
            tasks_converted=len([t for t in task_details if t.dag_id == dag_id and t.source != "fallback"]),
            tasks_flagged=len([t for t in task_details if t.dag_id == dag_id and t.review_required]),
            validation_passed=state.validation_results.get(dag_id, ValidationResult(dag_id=dag_id)).dagbag_valid,
        )
        for dag_id in state.generated_dags
    ]

    state.report = MigrationReport(
        total_jobs=len(state.parsed_jobs),
        total_plans=len(state.eme_plans),
        dags_generated=len(state.generated_dags),
        tasks_converted=len(task_details),
        tasks_flagged_for_review=sum(1 for t in task_details if t.review_required),
        skipped_plans=state.skipped_plans,
        agent_errors=state.agent_errors,
        dag_summaries=dag_summaries,
        task_details=task_details,
        overall_health_score=health_score
    )

    if state.status != "failed":
        state.status = "partial" if (state.skipped_plans or state.report.tasks_flagged_for_review > 0) else "success"

    return state
```

---

### Step 16 — `pipeline/orchestrator.py`

```python
from pipeline.state import PipelineState
from pipeline.agents.jil_parser import run_jil_parser
from pipeline.agents.eme_fetcher import run_eme_fetcher
from pipeline.agents.orchestration_analyzer import run_orchestration_analyzer
from pipeline.agents.conversion import run_conversion
from pipeline.agents.validation import run_validation
from pipeline.agents.report import run_report

def run_pipeline(jil_content: str, eme_host: str, confidence_threshold: float = 0.7) -> PipelineState:
    state = PipelineState(raw_jil=jil_content, confidence_threshold=confidence_threshold)

    state = run_jil_parser(state)
    if state.status == "failed":
        return run_report(state)

    state = run_eme_fetcher(state, eme_host)
    # Soft failure: continue even if some plans were skipped

    state = run_orchestration_analyzer(state)
    if state.status == "failed":
        return run_report(state)

    state = run_conversion(state)
    if state.status == "failed":
        return run_report(state)

    state = run_validation(state)
    state = run_report(state)

    return state
```

---

## Phase 4: REST API

### Step 17 — `api/models.py`

```python
from pydantic import BaseModel, field_validator
from typing import Optional, Dict, Any, List

class ConversionOptions(BaseModel):
    confidence_threshold: float = 0.7
    dry_run_validation: bool = False   # reserved for future use

    @field_validator("confidence_threshold")
    def validate_threshold(cls, v):
        if not 0.0 <= v <= 1.0:
            raise ValueError("confidence_threshold must be between 0.0 and 1.0")
        return v

class ConvertRequest(BaseModel):
    repo_url: Optional[str] = None
    branch: str = "main"
    jil_path: Optional[str] = None
    jil_content: Optional[str] = None
    eme_host: str
    options: ConversionOptions = ConversionOptions()

class ConvertResponse(BaseModel):
    job_id: str
    status: str = "running"

class DagResult(BaseModel):
    dag_id: str
    filename: str
    content: str
    validation: Dict[str, Any]

class StatusResponse(BaseModel):
    job_id: str
    status: str
    dags: Optional[List[DagResult]] = None
    report: Optional[Dict[str, Any]] = None
```

---

### Step 18 — `api/main.py`

Key implementation points:

1. **API key auth middleware** — read `API_KEY` from env; reject requests with wrong key (403)
2. **GitHub JIL fetcher** — read `GITHUB_TOKEN` from env; use `httpx` to call GitHub REST API; parse owner/repo/path from `repo_url`
3. **Job store** — `OrderedDict[str, dict]`; evict on: TTL > 24h OR size > 1000 entries
4. **`POST /convert`** — validate request, fetch JIL, enqueue `_run_and_store` via `background_tasks.add_task`, return `{job_id, status: "running"}`
5. **`GET /status/{job_id}`** — return job status; if complete, serialize `state.generated_dags` and `state.report`

Environment variables required:
- `ANTHROPIC_API_KEY` — Anthropic API key
- `GITHUB_TOKEN` — GitHub personal access token
- `API_KEY` — service API key for auth
- `EME_HOST` — default EME server (can be overridden per request)

---

## Phase 5: Test Suite

### Step 19 — `tests/fixtures/`

**`sample_jobs.jil`** — Create a realistic JIL file with:
- 1 BOX job (`job_type: BOX`) with `run_calendar: weekdays` and `start_times: 08:00`
- 3 CMD jobs inside the box:
  - Job A: `command: air sandbox run ReadCustomers.pset -batch` (no conditions)
  - Job B: `command: air sandbox run ProcessOrders.pset -batch` with `condition: s(JobA)`
  - Job C: `command: air sandbox run WriteOutput.pset -batch` with `condition: s(JobB)`

**`sample_plan.xml`** — Create a realistic EME XML export with:
- Plan name: `ReadCustomers.pset`
- 2 phases: `phase_1` (read), `phase_2` (transform)
- Components: `read_file` (phase_1), `run_sql` (phase_2), `write_file` (phase_2)
- Component connections (read_file output → run_sql input → write_file input)

**`expected_dag.py`** — The expected Airflow DAG for the above JIL + plan:
- DAG ID: `box_job_name` (snake_case of box job name)
- `catchup=False`
- Tasks: one per component per plan
- `task_a >> task_b >> task_c` dependency chain
- All GCP operators with correct import paths

---

### Step 20 — `tests/test_*.py`

**`tests/test_jil_parser.py`**
- `test_parse_box_job` — BOX job extracted with correct `job_type="BOX"`
- `test_parse_cmd_job_with_plan` — `air sandbox run MyPlan.pset` → `abinitio_plan="MyPlan.pset"`
- `test_parse_success_condition` — `s(JobA)` → `Condition(type=SUCCESS, job_name="JobA")`
- `test_parse_compound_and_condition` — `s(JobA) & f(JobB)` → two Conditions
- `test_job_without_plan` — CMD job with non-Ab-Initio command → `abinitio_plan=None`
- `test_schedule_extraction` — `run_calendar: weekdays` → `JobSchedule(run_calendar="weekdays", requires_manual_review=True)`

**`tests/test_eme_fetcher.py`**
- `test_safe_plan_name_passes` — `"MyPlan.pset"` passes regex
- `test_path_traversal_rejected` — `"../../evil.pset"` raises `ValueError`
- `test_semicolon_rejected` — `"plan;cmd.pset"` raises `ValueError`
- `test_retry_on_failure` — mock subprocess: fail × 2, succeed × 1; verify 3 calls made
- `test_soft_failure_after_3_retries` — mock subprocess: fail × 3; plan in `skipped_plans`, `AgentError` in `agent_errors`

**`tests/test_conversion.py`**
- `test_known_mapping_confidence_1` — `read_file` → `GCSToLocalFilesystemOperator`, confidence=1.0, source="known_mapping"
- `test_below_threshold_bash_fallback` — LLM returns confidence=0.4; operator=`BashOperator`, `review_required=True`
- `test_sub_plan_trigger_dag_run` — `trigger_dag` component → `TriggerDagRunOperator`, `wait_for_completion=True`
- `test_generated_dag_has_catchup_false` — generated Python contains `catchup=False`
- `test_generated_dag_has_retries_in_default_args` — `retries=3` in `default_args`

**`tests/test_validation.py`**
- `test_valid_dag_passes_syntax` — well-formed DAG → `syntax_valid=True`
- `test_valid_dag_passes_dagbag` — well-formed DAG → `dagbag_valid=True`
- `test_syntax_error_caught` — `def foo(:` → `syntax_valid=False` with error message
- `test_missing_import_caught_by_dagbag` — `from nonexistent.module import X` → `dagbag_valid=False`

---

## Phase 6: End-to-End Verification

### Step 21 — Verification Checklist

Run these in order before considering the implementation complete:

```
[ ] pytest tests/ -v                                    → all tests pass
[ ] uvicorn api.main:app --reload                       → server starts, no import errors
[ ] POST /convert with sample_jobs.jil                  → returns job_id immediately
[ ] GET /status/{job_id} (poll)                         → returns status: success/partial
[ ] Inspect generated DAG:
    [ ] ast.parse(dag_content) succeeds
    [ ] contains catchup=False
    [ ] contains retries=3 in default_args
    [ ] TriggerDagRunOperator has wait_for_completion=True (if sub-plans present)
    [ ] start_date is a fixed datetime, not datetime.now()
    [ ] DAG has tags and description
[ ] airflow dags validate <generated_dag_file>          → no import errors
[ ] overall_health_score is in range 0.0–1.0
[ ] POST /convert with plan name "../../evil.pset"      → plan skipped, not executed
[ ] POST /convert with invalid API key                  → 403 Forbidden
[ ] POST /convert with confidence_threshold=1.5         → 422 Validation Error
```

---

## Security Checklist (Pre-Deployment)

```
[ ] SAFE_PLAN_NAME_RE has no / in character class (prevents path traversal)
[ ] subprocess.run(shell=False) in eme_tools.py — never shell=True
[ ] GITHUB_TOKEN only from env var — not logged, not in API response
[ ] API_KEY validation on all endpoints
[ ] EME credentials only from env vars
[ ] Generated DAG files use Airflow Connections/Variables — no hardcoded GCP credentials
[ ] All environment variables documented in README
```
