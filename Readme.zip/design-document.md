# Design Document: AutoSys → Ab Initio → Airflow DAG Migration Tool

**Date:** 2026-04-10
**Status:** Approved
**Spec Review:** Passed (3 iterations)

---

## 1. Problem Statement

Enterprise data workflows are orchestrated at two legacy layers that must be migrated to Google Cloud Composer (Apache Airflow):

| Layer | System | Storage | Invocation |
|-------|--------|---------|-----------|
| Job scheduling & dependencies | AutoSys | JIL files in GitHub | Box jobs, CMD jobs, condition chains |
| ETL compute logic | Ab Initio | EME (Enterprise Meta Environment) | `air sandbox run MyPlan.pset -batch` in AutoSys CMD job |

The migration requires converting **both orchestration layers** into production-grade Airflow DAGs that follow Google Cloud Composer industry standards.

---

## 2. Goals

- Parse AutoSys JIL files from a GitHub repository
- Identify Ab Initio plan names referenced in JIL `command:` attributes
- Retrieve Ab Initio plan definitions from EME via `air repository export`
- Convert the two-layer orchestration into Airflow DAGs using GCP-native operators
- Validate generated DAGs for syntax and import correctness
- Return DAGs and a migration report via a REST API
- Flag low-confidence conversions for human review before production deployment

---

## 3. Non-Goals

- Full task-level dry-run execution (requires live GCP credentials — deferred to human review)
- AutoSys calendar-to-cron conversion for complex run_calendar definitions (flagged for review)
- Modifying existing AutoSys or Ab Initio systems

---

## 4. Approach: Sequential Multi-Agent Pipeline

A **custom agent loop** using the Anthropic Claude Sonnet 4.5 API. Six specialized agents run in sequence, each with a defined tool set and Pydantic output schema. A `PipelineState` object flows through all agents.

This approach was chosen over a single monolithic agent (context window limits, no fault isolation) and a hierarchical planner (unnecessary overhead for a fixed-structure pipeline).

---

## 5. Two-Layer Orchestration Model

The key design insight is making both orchestration layers explicit in a unified model before conversion:

### AutoSys Layer → DAG Structure
| AutoSys Concept | Airflow Equivalent |
|---|---|
| BOX job | DAG (one DAG per box) |
| CMD job | Task within DAG |
| `condition: s(JobA)` | `task_a >> task_b` dependency |
| `run_calendar` / `start_times` | DAG `schedule` (cron expression) |
| Complex calendar logic | `schedule_requires_review=True` flag |

### Ab Initio Layer → Task Content
| Ab Initio Concept | Airflow Equivalent |
|---|---|
| Plan phase | Ordered group of tasks |
| Component (read_file, run_sql, etc.) | GCP-native operator |
| Sub-plan reference | `TriggerDagRunOperator(wait_for_completion=True)` |
| Component parameters | Operator task arguments |

---

## 6. Component Mapping Strategy

Ab Initio component types map to GCP operators in two ways:

**Known mappings** — defined in `config/mappings.yaml`, always applied first:
| Ab Initio Type | GCP Operator |
|---|---|
| `read_file` | `GCSToLocalFilesystemOperator` |
| `write_file` | `LocalFilesystemToGCSOperator` |
| `run_sql` | `BigQueryExecuteQueryOperator` |
| `run_program` | `BashOperator` |
| `sort`, `join`, `rollup`, `gather`, `dedup_sorted` | `DataprocSubmitJobOperator` |
| `reformat` | `DataflowTemplateOperator` |
| `trigger_dag` | `TriggerDagRunOperator` |

**LLM inference** — for component types not in the registry, Claude Sonnet 4.5 is called to reason about the best operator from component name, parameters, and context.

**Confidence scoring:**
- `1.0` — exact known mapping
- `0.7–0.9` — high-confidence LLM inference
- `< confidence_threshold` (default 0.7) — `BashOperator` fallback + `review_required: true`

---

## 7. Airflow Industry Standards

All generated DAGs enforce these standards:

- DAG IDs in `snake_case`, unique per box job
- No top-level code with side effects
- `start_date` is a fixed date from AutoSys job metadata — never `datetime.now()`
- `catchup=False` by default; jobs with `run_calendar` flagged for manual review
- All GCP operators include `project_id` and `location`
- `retries=3`, `retry_delay=timedelta(minutes=5)` in `default_args`
- DAG has `tags=["migrated", "autosys", box_name]` and `description`
- Minimum Airflow version: **2.4+** (required for `TriggerDagRunOperator(wait_for_completion=True)`)

---

## 8. Error Handling Design

| Failure Mode | Example | Behavior |
|---|---|---|
| Hard failure | JIL unparseable | Pipeline halts; `status: failed`; error in report |
| Soft failure | EME export fails for one plan | Plan skipped + flagged; remaining plans continue |
| Low confidence | LLM confidence < threshold | `BashOperator` fallback; task flagged for review |
| Agent loop overflow | > 20 LLM iterations | `AgentError` raised; pipeline halts |
| Rate limit | `anthropic.RateLimitError` | 60-second backoff, then retry |

**Partial success:** The API always returns successfully converted DAGs even when some fail.

---

## 9. Security Design

| Threat | Mitigation |
|---|---|
| Shell injection via plan names | Allowlist regex `^[a-zA-Z0-9_\-\.]+\.pset$`; `subprocess.run(shell=False)` |
| GitHub token exposure | `GITHUB_TOKEN` env var only; never logged or in response |
| Unauthorized API access | API key middleware on all endpoints (`API_KEY` env var) |
| EME credential exposure | `EME_HOST`, credentials via env vars only |
| Secret leakage in DAG files | GCP params use Airflow Connections/Variables — no hardcoded secrets |

---

## 10. Validation Strategy

Agent 5 performs **import-level validation** (not full task execution):

1. **Syntax validation** — `ast.parse(dag_code)`: catches Python syntax errors
2. **DagBag validation** — Airflow `DagBag(dag_folder=tmpdir, include_examples=False)` with minimal SQLite metadb in a temp directory: catches import errors, missing modules, DAG construction errors

Full `airflow dags test` (actual task execution against GCP) is **not** performed at API call time — it requires live GCP credentials and is explicitly deferred to the human review step.

---

## 11. API Design

### Async Job Model
```
POST /convert  → { job_id, status: "running" }   (immediate)
GET  /status/{job_id} → { job_id, status, dags[], report }  (poll)
```

### Job Store (MVP)
In-memory `OrderedDict`: max 1,000 entries, 24-hour TTL, FIFO eviction on overflow.
Production upgrade path: Redis or Cloud Tasks.

---

## 12. Technology Decisions

| Decision | Choice | Rationale |
|---|---|---|
| API framework | FastAPI | Async-native, Pydantic v2 integration, automatic OpenAPI docs |
| Data validation | Pydantic v2 | Strict schema enforcement at every agent handoff |
| LLM | Claude Sonnet 4.5 | Required; best balance of reasoning quality and speed for inference tasks |
| DAG validation | Airflow as library | Authoritative DagBag import check without a full Airflow server |
| Templating | Jinja2 | Industry standard for code generation; separates structure from logic |
| Testing | pytest + pytest-asyncio | Standard Python testing; async support for FastAPI |
